﻿using MediaBrowser.Controller.Net;
using MediaBrowser.Model.Logging;
using MediaBrowser.Model.Net;
using MediaBrowser.Model.Serialization;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Emby.WebSocket
{
    // Emby auto-discovers this because it implements IWebSocketListener
    public class WebSocketHandler : IWebSocketListener
    {
        private readonly IJsonSerializer _json;
        private readonly ILogger _logger;

        public string Name => "WebSocket";

        public WebSocketHandler(IJsonSerializer json, ILogger logger)
        {
            _json = json;
            _logger = logger;
        }

        public async Task ProcessMessage(WebSocketMessageInfo message)
        {
            _logger.Info("[WebSocket] Incoming raw: {0}", message.Data);

            JsonMessage msg;
            try
            {
                msg = _json.DeserializeFromString<JsonMessage>(message.Data);
            }
            catch (Exception ex)
            {
                _logger.ErrorException("[WebSocket] Failed to parse JSON", ex);
                return;
            }

            switch (msg?.Type)
            {
                case null:
                    _logger.Warn("[WebSocket] Message type is null");
                    return;
                case "ping":
                    Reply(message, "pong.",msg);
                    return;
                case "startscan":
                    Reply(message, "I heard you! StartScan.", msg);
                    // Here you would initiate the image corruption scan process
                    return;
                default:
                    _logger.Warn("[WebSocket] Unknown message type: {0}", msg.Type);
                    return;
            }
            
           

        }
        async void Reply(WebSocketMessageInfo message, string txtreply, JsonMessage msg)
        {
            _logger.Info("[WebSocket] Got PING from {0}", msg.UserId);

            var response = new JsonMessage
            {
                Type = txtreply,
                UserId = msg.UserId,
                Payload = "Server time: " + DateTime.UtcNow.ToString("HH:mm:ss")
            };

            var json = _json.SerializeToString(response);

            var reply = new WebSocketMessage<string>
            {
                MessageType = Name,
                Data = json
            };

            await message.Connection.SendAsync(reply, CancellationToken.None);
            _logger.Info("[WebSocket] Sent {0} back to client {1}", txtreply, message.Connection.Id);
        }

    }
}
