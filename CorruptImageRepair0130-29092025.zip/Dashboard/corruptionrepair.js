﻿define([], function () {
    return function (view) {
        var btn, logBox;

        function log(msg) {
            var ts = new Date().toLocaleTimeString();
            logBox.value += "[" + ts + "] " + msg + "\n";
            logBox.scrollTop = logBox.scrollHeight;
        }

        function onWebSocketMessage(e, msg) {
            // Emby sends { MessageType: "WebSocket", Data: "<jsonstring>" }
            if (msg && msg.MessageType === "WebSocket") {
                try {
                    var data = JSON.parse(msg.Data || "{}");
                    log("✅ Response: " + JSON.stringify(data));
                } catch (ex) {
                    log("⚠️ Raw: " + (msg.Data || ""));
                }
            }
        }

        view.addEventListener("viewshow", function () {
            btnPing = view.querySelector("#btnPing");
            btnScan = view.querySelector("#btnScan");
            logBox = view.querySelector("#logBox");

            log("WebSocketTest loaded, ready.");

            // ✅ subscribe to WebSocket channel using Events.on
            Events.on(ApiClient, "message", onWebSocketMessage);

            btnPing.addEventListener("click", function () {
                log("Sending ping → WebSocket…");
                WebSocketReply("ping");
            });
            btnScan.addEventListener("click", function () {
                log("Sending startscan → WebSocket…");
                WebSocketReply("startscan");
            });
            function WebSocketReply(msg) {
                var payload = {
                    Type: msg,
                    UserId: ApiClient.getCurrentUserId() || "",
                    Payload: "Hello from dashboard"
                };

                // must stringify to avoid deserialization error on server
                ApiClient.sendMessage("WebSocket", JSON.stringify(payload));
            }

        });

        view.addEventListener("viewdestroy", function () {
            // ✅ clean up listener when leaving page
            Events.off(ApiClient, "message", onWebSocketMessage);
        });
    };
});
